import streamlit as st
from data_crawling import *

def main():
	crawl_data(st)

if __name__ == '__main__':
    main()